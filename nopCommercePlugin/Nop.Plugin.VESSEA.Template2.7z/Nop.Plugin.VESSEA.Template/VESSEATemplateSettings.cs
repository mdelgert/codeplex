﻿using Nop.Core.Configuration;

namespace Nop.Plugin.VESSEA.Template
{
    public class VESSEATemplateSettings : ISettings
    {
        /// <summary>
        /// Gets or sets the value indicting whether this SMS provider is enabled
        /// </summary>
        public bool Enabled { get; set; }

        /// <summary>
        /// Gets or sets the Verizon email
        /// </summary>
        public string Test { get; set; }
    }

}
